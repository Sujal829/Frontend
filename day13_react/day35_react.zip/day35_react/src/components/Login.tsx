import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
const Login:React.FC = () => {
  const [email, setEmail] = useState<string>('');
  const [password, setPassord] = useState<string>('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit=(e: React.FormEvent)=>{
    e.preventDefault();
    const ok = login(email,password);
    if(ok){
      navigate('/dashboard');
    }else{
      alert('Invalid Creds')
    }
  }
  return (
    <div style={{ padding: 20}}>
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" value={email} onChange={(e) => setEmail(e.target.value)} />
        <br />
        <input type="password" value={password} onChange={(e) => setPassord(e.target.value)} />
        <button>Login</button>
      </form>
    </div>
  );
};

export default Login;